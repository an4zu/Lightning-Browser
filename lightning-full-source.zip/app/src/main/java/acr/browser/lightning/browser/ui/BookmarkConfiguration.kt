package acr.browser.lightning.browser.ui

/**
 * Supported bookmark drawer orientations.
 */
enum class BookmarkConfiguration {
    LEFT,
    RIGHT
}
