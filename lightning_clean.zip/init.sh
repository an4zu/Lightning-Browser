#!/bin/bash

echo "=== Lightning Browser 环境初始化开始 ==="

# -----------------------------
# 1. 停止 Gradle 守护进程
# -----------------------------
echo "[1/6] 停止 Gradle 守护进程..."
./gradlew --stop >/dev/null 2>&1

# -----------------------------
# 2. 清理所有 Gradle 缓存
# -----------------------------
echo "[2/6] 清理 Gradle 缓存..."
rm -rf ~/.gradle/caches
rm -rf ~/.gradle/configuration-cache
rm -rf ~/.gradle/kotlin
rm -rf ~/.gradle/daemon
rm -rf ~/.gradle/native
rm -rf ~/.gradle/notifications

# -----------------------------
# 3. 清理项目构建目录
# -----------------------------
echo "[3/6] 清理项目 build 目录..."
rm -rf app/build
rm -rf build

# -----------------------------
# 4. 禁用 configuration cache
# -----------------------------
echo "[4/6] 禁用 configuration cache..."
if ! grep -q "org.gradle.unsafe.configuration-cache=false" gradle.properties; then
    echo "org.gradle.unsafe.configuration-cache=false" >> gradle.properties
fi

# -----------------------------
# 5. 设置 JDK 17（AGP 8.x 需要）
# -----------------------------
echo "[5/6] 设置 JDK 17..."
export JAVA_HOME=/usr/lib/jvm/msopenjdk-17
export PATH=$JAVA_HOME/bin:$PATH

# -----------------------------
# 6. 预热 Gradle（第一次构建会快很多）
# -----------------------------
echo "[6/6] 预热 Gradle..."
./gradlew --version >/dev/null 2>&1

echo "=== 环境初始化完成！你现在可以构建 Plus 版 ==="
echo "运行： ./gradlew assembleLightningPlusRelease"
