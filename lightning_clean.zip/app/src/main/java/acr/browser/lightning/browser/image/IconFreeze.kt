package acr.browser.lightning.browser.image

import javax.inject.Qualifier

/**
 * The frozen icon qualifier
 */
@Qualifier
annotation class IconFreeze
