#!/bin/bash

echo "=== Lightning Browser JDK 修复脚本开始 ==="

# -----------------------------
# 1. 切换系统默认 JDK 到 17
# -----------------------------
echo "[1/5] 切换系统默认 JDK 到 17..."

sudo update-alternatives --set java /usr/lib/jvm/msopenjdk-17/bin/java >/dev/null 2>&1
sudo update-alternatives --set javac /usr/lib/jvm/msopenjdk-17/bin/javac >/dev/null 2>&1

echo "当前 Java 版本："
java -version | head -n 1

# -----------------------------
# 2. 设置 JAVA_HOME
# -----------------------------
echo "[2/5] 设置 JAVA_HOME..."

export JAVA_HOME=/usr/lib/jvm/msopenjdk-17
export PATH=$JAVA_HOME/bin:$PATH

# 写入到当前 shell 的 profile（让未来终端也生效）
if ! grep -q "JAVA_HOME=/usr/lib/jvm/msopenjdk-17" ~/.bashrc; then
    echo "export JAVA_HOME=/usr/lib/jvm/msopenjdk-17" >> ~/.bashrc
    echo "export PATH=\$JAVA_HOME/bin:\$PATH" >> ~/.bashrc
fi

# -----------------------------
# 3. 强制 Gradle 使用 JDK 17
# -----------------------------
echo "[3/5] 配置 Gradle 使用 JDK 17..."

if ! grep -q "org.gradle.java.home" gradle.properties; then
    echo "org.gradle.java.home=/usr/lib/jvm/msopenjdk-17" >> gradle.properties
else
    sed -i 's|org.gradle.java.home=.*|org.gradle.java.home=/usr/lib/jvm/msopenjdk-17|' gradle.properties
fi

# -----------------------------
# 4. 清理 Gradle Daemon 和缓存
# -----------------------------
echo "[4/5] 清理 Gradle Daemon 和缓存..."

./gradlew --stop >/dev/null 2>&1
rm -rf ~/.gradle/daemon
rm -rf ~/.gradle/caches
rm -rf ~/.gradle/configuration-cache

# -----------------------------
# 5. 输出最终确认
# -----------------------------
echo "[5/5] 最终确认："

echo "JAVA_HOME = $JAVA_HOME"
echo "Java version:"
java -version | head -n 1

echo
echo "=== JDK 修复完成！你现在可以构建 Plus 版 ==="
echo "运行： ./gradlew assembleLightningPlusRelease"
