package acr.browser.lightning

import android.app.Application

class TestApplication : Application()