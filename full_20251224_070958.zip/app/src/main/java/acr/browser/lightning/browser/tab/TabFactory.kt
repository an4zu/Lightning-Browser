package acr.browser.lightning.browser.tab

import acr.browser.lightning.browser.di.CacheDir
import acr.browser.lightning.browser.di.DiskScheduler
import acr.browser.lightning.browser.di.FilesDir
import acr.browser.lightning.browser.di.MainScheduler
import android.app.Application
import android.webkit.WebView
import androidx.webkit.WebViewAssetLoader.InternalStoragePathHandler
import io.reactivex.rxjava3.core.Scheduler
import io.reactivex.rxjava3.core.Single
import java.io.File
import javax.inject.Inject

/**
 * Constructs a [TabModel].
 */
class TabFactory @Inject constructor(
    private val app: Application,
    private val webViewFactory: WebViewFactory,
    private val tabWebViewClientFactory: TabWebViewClient.Factory,
    private val tabAdapterFactory: TabAdapter.Factory,
    @DiskScheduler private val diskScheduler: Scheduler,
    @MainScheduler private val mainScheduler: Scheduler,
    @CacheDir private val cacheDir: File,
    @FilesDir private val filesDir: File,
) {

    /**
     * Constructs a tab from the [webView] with the provided [tabInitializer].
     */
    fun constructTab(
        tabInitializer: TabInitializer,
        webView: WebView,
        tabType: TabModel.Type
    ): Single<TabModel> {

        val faviconHandler = Single.just(
            InternalStoragePathHandler(app, File(cacheDir, "favicon-cache"))
        )

        val htmlHandler = Single.just(
            InternalStoragePathHandler(app, File(filesDir, "generated-html"))
        )

        return faviconHandler.zipWith(htmlHandler, ::Pair)
            .subscribeOn(diskScheduler)
            .observeOn(mainScheduler)
            .map { (faviconHandler, htmlHandler) ->

                val headers = webViewFactory.createRequestHeaders()

                // ⭐ 创建 WebViewClient
                val webViewClient = tabWebViewClientFactory.create(
                    headers,
                    faviconHandler,
                    htmlHandler
                )

                // ⭐ 创建 TabModel
                val tabModel = tabAdapterFactory.create(
                    tabInitializer = tabInitializer,
                    webView = webView,
                    requestHeaders = headers,
                    tabWebViewClient = webViewClient,
                    tabType = tabType,
                )

                // ⭐ 订阅页面加载完成事件 → 通知 TabModel
                webViewClient.finishedObservable.subscribe {
                    tabModel.onPageFinished()
                }

                tabModel
            }
    }
}
