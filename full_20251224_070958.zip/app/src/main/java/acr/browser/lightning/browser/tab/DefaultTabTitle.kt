package acr.browser.lightning.browser.tab

import javax.inject.Qualifier

/**
 * The default title of a tab
 */
@Qualifier
annotation class DefaultTabTitle
