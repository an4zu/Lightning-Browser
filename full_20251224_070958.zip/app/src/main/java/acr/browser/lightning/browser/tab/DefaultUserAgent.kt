package acr.browser.lightning.browser.tab

import javax.inject.Qualifier

/**
 * The default user agent marker.
 */
@Qualifier
annotation class DefaultUserAgent
