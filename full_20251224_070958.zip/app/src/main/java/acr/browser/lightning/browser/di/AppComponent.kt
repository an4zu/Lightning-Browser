package acr.browser.lightning.browser.di

import acr.browser.lightning.BrowserApp
import acr.browser.lightning.ThemableBrowserActivity
import acr.browser.lightning.adblock.BloomFilterAdBlocker
import acr.browser.lightning.adblock.NoOpAdBlocker
import acr.browser.lightning.browser.search.SearchBoxModel
import acr.browser.lightning.device.BuildInfo
import acr.browser.lightning.dialog.LightningDialogBuilder
import acr.browser.lightning.search.SuggestionsAdapter
import acr.browser.lightning.settings.activity.ThemableSettingsActivity
import acr.browser.lightning.settings.fragment.AdBlockSettingsFragment
import acr.browser.lightning.settings.fragment.AdvancedSettingsFragment
import acr.browser.lightning.settings.fragment.BookmarkSettingsFragment
import acr.browser.lightning.settings.fragment.DebugSettingsFragment
import acr.browser.lightning.settings.fragment.DisplaySettingsFragment
import acr.browser.lightning.settings.fragment.GeneralSettingsFragment
import acr.browser.lightning.settings.fragment.PrivacySettingsFragment
import acr.browser.lightning.settings.fragment.RootSettingsFragment
import android.app.Application
import dagger.BindsInstance
import dagger.Component
import dagger.Module
import javax.inject.Singleton

@Singleton
@Component(modules = [AppModule::class, AppBindsModule::class, Submodules::class])
interface AppComponent {

    @Component.Builder
    interface Builder {

        @BindsInstance
        fun application(application: Application): Builder

        @BindsInstance
        fun buildInfo(buildInfo: BuildInfo): Builder

        fun build(): AppComponent
    }

    fun inject(fragment: BookmarkSettingsFragment)

    fun inject(builder: LightningDialogBuilder)

    fun inject(activity: ThemableBrowserActivity)

    fun inject(advancedSettingsFragment: AdvancedSettingsFragment)

    fun inject(app: BrowserApp)

    fun inject(activity: ThemableSettingsActivity)

    fun inject(fragment: PrivacySettingsFragment)

    fun inject(fragment: DebugSettingsFragment)

    fun inject(suggestionsAdapter: SuggestionsAdapter)

    fun inject(searchBoxModel: SearchBoxModel)

    fun inject(activity: RootSettingsFragment)

    fun inject(generalSettingsFragment: GeneralSettingsFragment)

    fun inject(displaySettingsFragment: DisplaySettingsFragment)

    fun inject(adBlockSettingsFragment: AdBlockSettingsFragment)

    fun provideBloomFilterAdBlocker(): BloomFilterAdBlocker

    fun provideNoOpAdBlocker(): NoOpAdBlocker

    fun browser2ComponentBuilder(): Browser2Component.Builder

}

@Module(subcomponents = [Browser2Component::class])
internal class Submodules
