#!/bin/bash

echo "=== Lightning Browser 环境完整性检查开始 ==="
echo

# -----------------------------
# 1. 检查关键目录
# -----------------------------
echo "[1/6] 检查关键目录结构..."

dirs=(
  "app/src/main/java/acr/browser/lightning/browser"
  "app/src/main/java/acr/browser/lightning/search"
  "app/src/main/java/acr/browser/lightning/history"
  "app/src/main/java/acr/browser/lightning/theme"
  "app/src/main/java/acr/browser/lightning/tab"
  "app/src/main/java/acr/browser/lightning/reading"
)

for d in "${dirs[@]}"; do
  if [ -d "$d" ]; then
    echo "  ✔ 存在: $d"
  else
    echo "  ✘ 缺失: $d"
  fi
done

echo

# -----------------------------
# 2. 检查关键文件
# -----------------------------
echo "[2/6] 检查关键类文件..."

files=(
  "app/src/main/java/acr/browser/lightning/browser/BrowserActivity.kt"
  "app/src/main/java/acr/browser/lightning/search/SearchEngineProvider.kt"
  "app/src/main/java/acr/browser/lightning/history/HistoryModel.kt"
  "app/src/main/java/acr/browser/lightning/theme/ThemeProvider.kt"
  "app/src/main/java/acr/browser/lightning/tab/TabsManager.kt"
  "app/src/main/java/acr/browser/lightning/reading/ReadingModeManager.kt"
)

for f in "${files[@]}"; do
  if [ -f "$f" ]; then
    echo "  ✔ 存在: $f"
  else
    echo "  ✘ 缺失: $f"
  fi
done

echo

# -----------------------------
# 3. 检查 BrowserActivity 是否为 open class
# -----------------------------
echo "[3/6] 检查 BrowserActivity 是否为 open class..."

if grep -q "open class BrowserActivity" app/src/main/java/acr/browser/lightning/browser/BrowserActivity.kt; then
  echo "  ✔ BrowserActivity 是 open class"
else
  echo "  ✘ BrowserActivity 不是 open class（会导致继承失败）"
fi

echo

# -----------------------------
# 4. 检查 Gradle 配置缓存是否禁用
# -----------------------------
echo "[4/6] 检查 configuration-cache 设置..."

if grep -q "org.gradle.unsafe.configuration-cache=false" gradle.properties; then
  echo "  ✔ configuration-cache 已禁用"
else
  echo "  ✘ configuration-cache 未禁用（可能导致 kapt 崩溃）"
fi

echo

# -----------------------------
# 5. 检查 JDK 版本
# -----------------------------
echo "[5/6] 检查 JDK 版本..."

java -version 2>&1 | head -n 1

echo

# -----------------------------
# 6. 检查 Gradle 是否能正常运行
# -----------------------------
echo "[6/6] 检查 Gradle 可用性..."

./gradlew --version >/dev/null 2>&1
if [ $? -eq 0 ]; then
  echo "  ✔ Gradle 可正常运行"
else
  echo "  ✘ Gradle 无法运行"
fi

echo
echo "=== 检查完成 ==="
